package com.iosqs;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

public class IconBtn extends View {
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ic = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path;
    private boolean active;
    public int onBg = 0xFF0A84FF, offBg = 0x55FFFFFF, onIcon = 0xFFFFFFFF, offIcon = 0xFFFFFFFF;

    public IconBtn(Context c, String pathData) {
        super(c);
        path = Sys.parsePath(pathData);
        ic.setStyle(Paint.Style.FILL);
    }

    public void setActive(boolean a) {
        if (a != active) { active = a; invalidate(); }
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight(), r = Math.min(w, h) / 2f;
        bg.setColor(active ? onBg : offBg);
        cv.drawCircle(w / 2f, h / 2f, r, bg);
        if (path != null) {
            float s = r / 24f;
            ic.setColor(active ? onIcon : offIcon);
            cv.save();
            cv.translate(w / 2f - 12f * s, h / 2f - 12f * s);
            cv.scale(s, s);
            cv.drawPath(path, ic);
            cv.restore();
        }
    }
}
