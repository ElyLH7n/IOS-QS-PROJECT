package com.iosqs;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import de.robv.android.xposed.XposedBridge;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.WeakHashMap;

/**
 * Susun ulang area atas panel QS (personal_tiles_container) jadi mirip iOS:
 *   [ Blok konektivitas 2x2 | Media 2x2 ]
 *   [ Kunci rotasi + Cast   | Slider      ]
 *   [ Perangkat Saya        | Slider      ]
 * Caranya: view asli digeser dengan translasi, Wi-Fi/Bluetooth/Ringer disembunyikan,
 * lalu blok buatan ditempel di atasnya.
 */
public final class Layouter {
    private static final String PKG = "com.android.systemui";
    private static final WeakHashMap<ViewGroup, Holder> HOLDERS = new WeakHashMap<>();
    private static boolean logged;

    private static final class Holder {
        ConnectivityBlock conn;
        StripBlock strip;
        float ox, oy1, oy2;
    }

    private static int id(Context c, String name) {
        return c.getResources().getIdentifier(name, "id", PKG);
    }

    private static View find(View root, int id) {
        return id == 0 ? null : root.findViewById(id);
    }

    public static void apply(final ViewGroup rv) {
        if (rv.getId() == View.NO_ID) return;
        Context c = rv.getContext();
        int pid = id(c, "personal_tiles_container");
        if (pid == 0 || rv.getId() != pid) return;

        int idMedia = id(c, "oplus_qs_media_panel");
        int idSlider = id(c, "qs_brightness_volume_layout");
        int idRinger = id(c, "oplus_qs_three_stage_layout");

        View media = null, slider = null, ringer = null;
        List<View> tiles = new ArrayList<>();
        for (int i = 0; i < rv.getChildCount(); i++) {
            View cell = rv.getChildAt(i);
            if (find(cell, idMedia) != null) media = cell;
            else if (find(cell, idSlider) != null) slider = cell;
            else if (find(cell, idRinger) != null) ringer = cell;
            else tiles.add(cell);
        }
        if (media == null || slider == null || tiles.size() < 2) return;

        Collections.sort(tiles, new Comparator<View>() {
            @Override public int compare(View a, View b) {
                return a.getTop() != b.getTop() ? a.getTop() - b.getTop() : a.getLeft() - b.getLeft();
            }
        });
        View wifi = tiles.get(0), bt = tiles.get(1);
        View mp = find(media, idMedia);
        if (mp == null || mp.getWidth() == 0 || wifi.getHeight() == 0) return;

        int rowH = wifi.getHeight();

        // 1) Media pindah ke kanan atas
        media.setTranslationX(bt.getLeft() - media.getLeft());
        media.setTranslationY(wifi.getTop() - media.getTop());
        // 2) Slider turun satu baris
        slider.setTranslationY(wifi.getTop() + 2 * rowH - slider.getTop());
        // 3) Sembunyikan yang digantikan
        wifi.setVisibility(View.INVISIBLE);
        bt.setVisibility(View.INVISIBLE);
        if (ringer != null) ringer.setVisibility(View.INVISIBLE);

        // 4) Ukuran dan posisi blok buatan (dalam koordinat parent)
        int inset = (media.getWidth() - mp.getWidth()) / 2;
        int blockW = mp.getWidth();
        int blockH = mp.getHeight();
        int stripH = rowH - (media.getHeight() - blockH);

        Holder h = HOLDERS.get(rv);
        if (h == null) {
            ViewGroup parent = (ViewGroup) rv.getParent();
            if (parent == null) return;
            h = new Holder();
            h.conn = new ConnectivityBlock(c);
            h.strip = new StripBlock(c);
            parent.addView(h.conn, new ViewGroup.LayoutParams(blockW, blockH));
            parent.addView(h.strip, new ViewGroup.LayoutParams(blockW, stripH));
            final Holder fh = h;
            Runnable sync = new Runnable() {
                @Override public void run() { sync(rv, fh); }
            };
            h.conn.preDraw = sync;
            h.strip.preDraw = sync;
            HOLDERS.put(rv, h);
            if (!logged) { logged = true; XposedBridge.log("IOSQS: blok ditempel (" + blockW + "x" + blockH + ")"); }
        }
        resize(h.conn, blockW, blockH);
        resize(h.strip, blockW, stripH);

        h.ox = rv.getLeft() + wifi.getLeft() + inset;
        h.oy1 = rv.getTop() + wifi.getTop();
        h.oy2 = rv.getTop() + wifi.getTop() + 2 * rowH;
        sync(rv, h);
    }

    private static void resize(View v, int w, int hh) {
        ViewGroup.LayoutParams lp = v.getLayoutParams();
        if (lp.width != w || lp.height != hh) {
            lp.width = w;
            lp.height = hh;
            v.setLayoutParams(lp);
        }
    }

    private static void sync(ViewGroup rv, Holder h) {
        int vis = rv.getVisibility() == View.VISIBLE ? View.VISIBLE : View.INVISIBLE;
        float a = rv.getAlpha();
        float tx = rv.getTranslationX(), ty = rv.getTranslationY();
        h.conn.setVisibility(vis);
        h.strip.setVisibility(vis);
        h.conn.setAlpha(a);
        h.strip.setAlpha(a);
        h.conn.setX(h.ox + tx);
        h.conn.setY(h.oy1 + ty);
        h.strip.setX(h.ox + tx);
        h.strip.setY(h.oy2 + ty);
    }
}
