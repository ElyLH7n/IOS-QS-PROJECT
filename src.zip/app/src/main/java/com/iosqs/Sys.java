package com.iosqs;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.graphics.Path;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import de.robv.android.xposed.XposedBridge;

public final class Sys {
    private Sys() {}

    public static Path parsePath(String d) {
        try {
            Class<?> c = Class.forName("android.util.PathParser");
            return (Path) c.getMethod("createPathFromPathData", String.class).invoke(null, d);
        } catch (Throwable t) {
            XposedBridge.log("IOSQS: PathParser gagal: " + t);
            return null;
        }
    }

    public static void open(Context c, String action) {
        try {
            Intent i = new Intent(action);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable t) {
            XposedBridge.log("IOSQS: open " + action + " gagal: " + t);
        }
    }

    // ---- Wi-Fi ----
    public static boolean wifiOn(Context c) {
        try { return ((WifiManager) c.getSystemService(Context.WIFI_SERVICE)).isWifiEnabled(); }
        catch (Throwable t) { return false; }
    }
    public static void toggleWifi(Context c) {
        try {
            WifiManager w = (WifiManager) c.getSystemService(Context.WIFI_SERVICE);
            w.setWifiEnabled(!w.isWifiEnabled());
        } catch (Throwable t) { XposedBridge.log("IOSQS: wifi toggle gagal: " + t); }
    }

    // ---- Bluetooth ----
    public static boolean btOn(Context c) {
        try { return BluetoothAdapter.getDefaultAdapter().isEnabled(); }
        catch (Throwable t) { return false; }
    }
    public static void toggleBt(Context c) {
        try {
            BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
            if (a.isEnabled()) a.disable(); else a.enable();
        } catch (Throwable t) { XposedBridge.log("IOSQS: bt toggle gagal: " + t); }
    }

    // ---- Mode pesawat ----
    public static boolean airplaneOn(Context c) {
        try { return Settings.Global.getInt(c.getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) == 1; }
        catch (Throwable t) { return false; }
    }
    public static void toggleAirplane(Context c) {
        boolean on = airplaneOn(c);
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            cm.getClass().getMethod("setAirplaneMode", boolean.class).invoke(cm, !on);
            return;
        } catch (Throwable ignored) {}
        try {
            Settings.Global.putInt(c.getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, on ? 0 : 1);
            Intent i = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
            i.putExtra("state", !on);
            c.sendBroadcast(i);
        } catch (Throwable t) { XposedBridge.log("IOSQS: airplane toggle gagal: " + t); }
    }

    // ---- Data seluler ----
    public static boolean dataOn(Context c) {
        try { return ((TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE)).isDataEnabled(); }
        catch (Throwable t) { return false; }
    }
    public static void toggleData(Context c) {
        boolean on = dataOn(c);
        try {
            TelephonyManager tm = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            tm.getClass().getMethod("setDataEnabled", boolean.class).invoke(tm, !on);
            return;
        } catch (Throwable ignored) {}
        try {
            Runtime.getRuntime().exec(new String[]{"svc", "data", on ? "disable" : "enable"});
        } catch (Throwable t) { XposedBridge.log("IOSQS: data toggle gagal: " + t); }
    }

    // ---- Hotspot (hanya status; ketuk membuka pengaturan) ----
    public static boolean hotspotOn(Context c) {
        try {
            WifiManager w = (WifiManager) c.getSystemService(Context.WIFI_SERVICE);
            return (Boolean) w.getClass().getMethod("isWifiApEnabled").invoke(w);
        } catch (Throwable t) { return false; }
    }

    // ---- Kunci rotasi ----
    public static boolean rotationLocked(Context c) {
        try { return Settings.System.getInt(c.getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 1) == 0; }
        catch (Throwable t) { return false; }
    }
    public static void toggleRotationLock(Context c) {
        try {
            Settings.System.putInt(c.getContentResolver(), Settings.System.ACCELEROMETER_ROTATION,
                    rotationLocked(c) ? 1 : 0);
        } catch (Throwable t) { XposedBridge.log("IOSQS: rotasi toggle gagal: " + t); }
    }
}
