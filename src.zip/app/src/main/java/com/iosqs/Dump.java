package com.iosqs;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import de.robv.android.xposed.XposedBridge;
import java.io.File;
import java.io.FileOutputStream;
import java.util.regex.Pattern;

/** Diagnosa: tulis struktur view tile ColorOS ke file supaya efek kacanya bisa dipelajari. */
final class Dump {
    private Dump() {}

    static String name(View v) {
        int id = v.getId();
        if (id == View.NO_ID) return "-";
        try { return v.getResources().getResourceEntryName(id); }
        catch (Throwable t) { return "#" + Integer.toHexString(id); }
    }

    static String drw(Drawable d) {
        if (d == null) return "null";
        StringBuilder s = new StringBuilder(d.getClass().getName());
        if (d instanceof LayerDrawable) {
            LayerDrawable l = (LayerDrawable) d;
            s.append("[");
            for (int i = 0; i < l.getNumberOfLayers() && i < 6; i++) s.append(drw(l.getDrawable(i))).append(",");
            s.append("]");
        }
        return s.toString();
    }

    static void tree(View v, int depth, StringBuilder sb) {
        if (sb.length() > 60000) return;
        for (int i = 0; i < depth; i++) sb.append("  ");
        sb.append(v.getClass().getName()).append(" id=").append(name(v))
          .append(" ").append(v.getWidth()).append("x").append(v.getHeight())
          .append(" vis=").append(v.getVisibility()).append(" a=").append(v.getAlpha())
          .append(" layer=").append(v.getLayerType())
          .append(" bg=").append(drw(v.getBackground()))
          .append(" fg=").append(drw(v.getForeground()));
        if (v instanceof ImageView) sb.append(" src=").append(drw(((ImageView) v).getDrawable()));
        try {
            if (v.getOutlineProvider() != null) sb.append(" outline=").append(v.getOutlineProvider().getClass().getName());
        } catch (Throwable ignored) {}
        sb.append("\n");
        String m = methods(v.getClass());
        if (m.length() > 0) sb.append("    [metode terkait: ").append(m).append("]\n");
        if (v instanceof ViewGroup && depth < 7) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) tree(g.getChildAt(i), depth + 1, sb);
        }
    }

    private static final Pattern KEY = Pattern.compile("(?i)blur|glass|refract|effect|shader|liquid|material");

    static String methods(Class<?> c) {
        StringBuilder s = new StringBuilder();
        int guard = 0;
        while (c != null && guard++ < 4) {
            String n = c.getName();
            if (n.startsWith("android.view.") || n.startsWith("android.widget.") || n.equals("java.lang.Object")) break;
            try {
                for (java.lang.reflect.Method m : c.getDeclaredMethods()) {
                    if (KEY.matcher(m.getName()).find() && s.length() < 300) s.append(m.getName()).append(",");
                }
            } catch (Throwable ignored) {}
            c = c.getSuperclass();
        }
        return s.toString();
    }

    static void write(Context c, String text) {
        try {
            File f = new File(c.getFilesDir(), "iosqs_dump.txt");
            FileOutputStream o = new FileOutputStream(f);
            o.write(text.getBytes("UTF-8"));
            o.close();
            f.setReadable(true, false);
            XposedBridge.log("IOSQS: dump ditulis ke " + f.getAbsolutePath());
        } catch (Throwable t) {
            XposedBridge.log("IOSQS: dump gagal: " + t);
        }
    }
}
