package com.iosqs;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;

public class ConnectivityBlock extends BaseBlock {
    // Path ikon Material (viewport 24x24)
    static final String P_AIR = "M21,16v-2l-8,-5V3.5c0,-0.83 -0.67,-1.5 -1.5,-1.5S10,2.67 10,3.5V9l-8,5v2l8,-2.5V19l-2,1.5V22l3.5,-1 3.5,1v-1.5L13,19v-5.5l8,2.5z";
    static final String P_WIFI = "M1,9l2,2c4.97,-4.97 13.03,-4.97 18,0l2,-2C16.93,2.93 7.08,2.93 1,9zM9,17l3,3 3,-3c-1.65,-1.66 -4.34,-1.66 -6,0zM5,13l2,2c2.76,-2.76 7.24,-2.76 10,0l2,-2C15.14,9.14 8.87,9.14 5,13z";
    static final String P_BT = "M17.71,7.71L12,2h-1v7.59L6.41,5 5,6.41 10.59,12 5,17.59 6.41,19 11,14.41V22h1l5.71,-5.71 -4.3,-4.29 4.3,-4.29zM13,5.83l1.88,1.88L13,9.59V5.83zM14.88,16.29L13,18.17v-3.76l1.88,1.88z";
    static final String P_HOT = "M12,11c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2zM18,13c0,-3.31 -2.69,-6 -6,-6s-6,2.69 -6,6c0,2.22 1.21,4.15 3,5.19l1,-1.74c-1.19,-0.7 -2,-1.97 -2,-3.45 0,-2.21 1.79,-4 4,-4s4,1.79 4,4c0,1.48 -0.81,2.75 -2,3.45l1,1.74c1.79,-1.04 3,-2.97 3,-5.19zM12,3C5.93,3 1,7.93 1,14c0,3.6 1.7,6.8 4.35,8.84l1,-1.73C4.15,19.4 3,16.8 3,14c0,-4.97 4.03,-9 9,-9s9,4.03 9,9c0,2.8 -1.15,5.4 -3.35,7.11l1,1.73C21.3,20.8 23,17.6 23,14c0,-6.07 -4.93,-11 -11,-11z";
    static final String P_DATA = "M16,17.01V10h-2v7.01h-3L15,21l4,-3.99h-3zM9,3L5,6.99h3V14h2V6.99h3L9,3z";

    static final int BLUE = 0xFF1F6BFF;
    private android.view.View glassBlock;
    private final IconBtn air, hot, wifi, data, bt;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable poll = new Runnable() {
        @Override public void run() { refresh(); handler.postDelayed(this, 1000); }
    };

    public ConnectivityBlock(final Context c) {
        super(c);
        setWillNotDraw(false);
        air = new IconBtn(c, P_AIR, 0xFFFF9500);
        hot = new IconBtn(c, P_HOT, BLUE);
        wifi = new IconBtn(c, P_WIFI, BLUE);
        data = new IconBtn(c, P_DATA, 0xFF34C759);
        bt = new IconBtn(c, P_BT, BLUE);
        for (View v : new View[]{air, hot, wifi, data, bt}) addView(v);

        air.setOnClickListener(new OnClickListener() { public void onClick(View v) { Sys.toggleAirplane(c); later(); } });
        wifi.setOnClickListener(new OnClickListener() { public void onClick(View v) { Sys.toggleWifi(c); later(); } });
        wifi.setOnLongClickListener(new OnLongClickListener() { public boolean onLongClick(View v) { Sys.open(c, Settings.ACTION_WIFI_SETTINGS); return true; } });
        bt.setOnClickListener(new OnClickListener() { public void onClick(View v) { Sys.toggleBt(c); later(); } });
        bt.setOnLongClickListener(new OnLongClickListener() { public boolean onLongClick(View v) { Sys.open(c, Settings.ACTION_BLUETOOTH_SETTINGS); return true; } });
        data.setOnClickListener(new OnClickListener() { public void onClick(View v) { Sys.toggleData(c); later(); } });
        hot.setOnClickListener(new OnClickListener() { public void onClick(View v) { Sys.open(c, "android.settings.TETHER_SETTINGS"); } });
    }

    private void later() { handler.postDelayed(new Runnable() { public void run() { refresh(); } }, 500); }

    private void refresh() {
        Context c = getContext();
        air.setActive(Sys.airplaneOn(c));
        wifi.setActive(Sys.wifiOn(c));
        bt.setActive(Sys.btOn(c));
        data.setActive(Sys.dataOn(c));
        hot.setActive(Sys.hotspotOn(c));
        for (View v : new View[]{air, hot, wifi, data, bt}) v.invalidate();
        invalidate();
    }

    @Override protected void onShown() { handler.post(poll); }
    @Override protected void onHidden() { handler.removeCallbacks(poll); }

    public void setGlass(android.view.View blockView, android.view.View circleView) {
        glassBlock = blockView;
        if (blockView != null) setBackground(null);
        for (IconBtn b : new IconBtn[]{air, hot, wifi, data, bt}) b.setGlass(circleView);
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        if (glassBlock != null) return;
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x30FFFFFF, 0x16FFFFFF});
        g.setCornerRadius(w * 0.2f);
        g.setStroke(Math.max(2, (int) (w * 0.006f)), 0x48FFFFFF);
        setBackground(g);
    }

    @Override
    protected void onDraw(android.graphics.Canvas cv) {
        android.view.View g = glassBlock;
        if (g == null || g.getWidth() <= 0 || g.getHeight() <= 0 || !g.isAttachedToWindow()) return;
        try {
            cv.save();
            cv.scale((float) getWidth() / g.getWidth(), (float) getHeight() / g.getHeight());
            g.draw(cv);
            cv.restore();
        } catch (Throwable t) {
            glassBlock = null;
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int W = r - l, H = b - t;
        int p = (int) (W * 0.08f), d = (int) (W * 0.36f);
        place(air, p, p, d, d);
        place(hot, W - p - d, p, d, d);
        place(wifi, p, H - p - d, d, d);
        int s = (int) (d * 0.44f), g = d - 2 * s;
        int rx = W - p - d, ry = H - p - d;
        place(data, rx, ry, s, s);
        place(bt, rx + s + g, ry, s, s);
    }
}
