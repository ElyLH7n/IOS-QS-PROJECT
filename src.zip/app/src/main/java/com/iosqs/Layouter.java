package com.iosqs;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import de.robv.android.xposed.XposedBridge;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.WeakHashMap;

/**
 * Susun ulang area atas panel QS (personal_tiles_container):
 *   [ Blok konektivitas 2x2 | Media 2x2 ]
 *   [ Kunci rotasi + Cast   | Slider      ]
 *   [ Perangkat Saya        | Slider      ]
 * Posisi diterapkan ulang di setiap frame (pre-draw) supaya tidak tertimpa animasi RecyclerView.
 */
public final class Layouter {
    private static final String PKG = "com.android.systemui";
    private static final WeakHashMap<ViewGroup, Holder> HOLDERS = new WeakHashMap<>();

    private static final class Holder {
        ConnectivityBlock conn;
        StripBlock strip;
        boolean skinned;
        int skinTries;
    }

    private static final class Cells {
        View media, slider, ringer, wifi, bt, mp;
    }

    private static int id(Context c, String name) {
        return c.getResources().getIdentifier(name, "id", PKG);
    }

    private static View find(View root, int id) {
        return id == 0 ? null : root.findViewById(id);
    }

    public static void apply(ViewGroup rv) {
        if (rv.getId() == View.NO_ID) return;
        Context c = rv.getContext();
        int pid = id(c, "personal_tiles_container");
        if (pid == 0 || rv.getId() != pid) return;

        Holder h = HOLDERS.get(rv);
        if (h == null) {
            Cells cs = scan(rv);
            ViewGroup parent = (ViewGroup) rv.getParent();
            if (cs == null || parent == null) return;
            h = new Holder();
            h.conn = new ConnectivityBlock(c);
            h.strip = new StripBlock(c);
            h.conn.setVisibility(View.INVISIBLE);
            h.strip.setVisibility(View.INVISIBLE);
            int blockW = cs.mp.getWidth(), blockH = cs.mp.getHeight();
            int stripH = Math.max(1, cs.wifi.getHeight() - (cs.media.getHeight() - blockH));
            parent.addView(h.conn, new ViewGroup.LayoutParams(blockW, blockH));
            parent.addView(h.strip, new ViewGroup.LayoutParams(blockW, stripH));
            disableAnimator(rv);
            final WeakReference<ViewGroup> ref = new WeakReference<>(rv);
            final Holder fh = h;
            Runnable r = new Runnable() {
                @Override public void run() {
                    ViewGroup v = ref.get();
                    if (v != null) update(v, fh);
                }
            };
            h.conn.preDraw = r;
            h.strip.preDraw = r;
            HOLDERS.put(rv, h);
            XposedBridge.log("IOSQS: blok ditempel (" + blockW + "x" + blockH + ")");
        }
        update(rv, h);
    }

    private static Cells scan(ViewGroup rv) {
        Context c = rv.getContext();
        int idMedia = id(c, "oplus_qs_media_panel");
        int idSlider = id(c, "qs_brightness_volume_layout");
        int idRinger = id(c, "oplus_qs_three_stage_layout");
        Cells cs = new Cells();
        List<View> tiles = new ArrayList<>();
        for (int i = 0; i < rv.getChildCount(); i++) {
            View cell = rv.getChildAt(i);
            if (find(cell, idMedia) != null) cs.media = cell;
            else if (find(cell, idSlider) != null) cs.slider = cell;
            else if (find(cell, idRinger) != null) cs.ringer = cell;
            else tiles.add(cell);
        }
        if (cs.media == null || cs.slider == null || tiles.size() < 2) return null;
        Collections.sort(tiles, new Comparator<View>() {
            @Override public int compare(View a, View b) {
                return a.getTop() != b.getTop() ? a.getTop() - b.getTop() : a.getLeft() - b.getLeft();
            }
        });
        cs.wifi = tiles.get(0);
        cs.bt = tiles.get(1);
        cs.mp = find(cs.media, idMedia);
        if (cs.mp == null || cs.mp.getWidth() == 0 || cs.wifi.getHeight() == 0) return null;
        return cs;
    }

    private static void update(ViewGroup rv, Holder h) {
        ViewGroup parent = (ViewGroup) rv.getParent();
        Cells cs = scan(rv);
        if (cs == null || parent == null || rv.getVisibility() != View.VISIBLE || !cs.wifi.isAttachedToWindow()) {
            h.conn.setVisibility(View.INVISIBLE);
            h.strip.setVisibility(View.INVISIBLE);
            return;
        }
        int rowH = cs.wifi.getHeight();

        // Geser view asli (diterapkan ulang tiap frame)
        cs.media.setTranslationX(cs.bt.getLeft() - cs.media.getLeft());
        cs.media.setTranslationY(cs.wifi.getTop() - cs.media.getTop());
        cs.slider.setTranslationY(cs.wifi.getTop() + 2 * rowH - cs.slider.getTop());
        cs.wifi.setVisibility(View.INVISIBLE);
        cs.bt.setVisibility(View.INVISIBLE);
        if (cs.ringer != null) cs.ringer.setVisibility(View.INVISIBLE);

        if (!h.skinned) skin(rv, parent, cs, h);

        int blockW = cs.mp.getWidth(), blockH = cs.mp.getHeight();
        int stripH = Math.max(1, rowH - (cs.media.getHeight() - blockH));
        resize(h.conn, blockW, blockH);
        resize(h.strip, blockW, stripH);

        int inset = (cs.media.getWidth() - blockW) / 2;
        int[] a = new int[2], b = new int[2];
        cs.wifi.getLocationInWindow(a);
        parent.getLocationInWindow(b);
        float x = a[0] - b[0] + inset;
        float y = a[1] - b[1];
        float alpha = rv.getAlpha() * cs.wifi.getAlpha();

        h.conn.setX(x);
        h.conn.setY(y);
        h.strip.setX(x);
        h.strip.setY(y + 2 * rowH);
        h.conn.setAlpha(alpha);
        h.strip.setAlpha(alpha);
        h.conn.setVisibility(View.VISIBLE);
        h.strip.setVisibility(View.VISIBLE);
    }

    /** Pinjam latar kaca bawaan ColorOS: dari panel media (blok) dan tile bulat tidak aktif (tombol). */
    private static void skin(ViewGroup rv, ViewGroup parent, Cells cs, Holder h) {
        if (h.skinTries++ > 40) { h.skinned = true; return; }
        Context c = rv.getContext();
        Drawable.ConstantState blockCS = null, circleCS = null;
        int[] circleState = null;
        String blockName = null, circleName = null, tileViewName = null;

        View bgv = find(cs.mp, id(c, "bg"));
        if (bgv != null) {
            Drawable d = bgv.getBackground();
            if (d == null && bgv instanceof ImageView) d = ((ImageView) bgv).getDrawable();
            if (d != null && d.getConstantState() != null) {
                blockCS = d.getConstantState();
                blockName = bgv.getClass().getName() + " -> " + d.getClass().getName();
            } else {
                blockName = bgv.getClass().getName() + " (tanpa drawable)";
            }
        }

        int idTileBg = id(c, "qs_tile_bg");
        int idCont = id(c, "oplus_separate_qs_resizeable_tile_container");
        View other = find(parent, id(c, "other_tiles_container"));
        if (other instanceof ViewGroup && idTileBg != 0) {
            ViewGroup og = (ViewGroup) other;
            for (int i = 0; i < og.getChildCount() && circleCS == null; i++) {
                View cell = og.getChildAt(i);
                View iv = cell.findViewById(idTileBg);
                View cont = cell.findViewById(idCont);
                if (iv == null) continue;
                if (cont instanceof CompoundButton && ((CompoundButton) cont).isChecked()) continue;
                Drawable d = iv.getBackground();
                if (d == null && iv instanceof ImageView) d = ((ImageView) iv).getDrawable();
                if (d != null && d.getConstantState() != null) {
                    circleCS = d.getConstantState();
                    circleState = d.getState();
                    tileViewName = iv.getClass().getName();
                    circleName = d.getClass().getName();
                }
            }
        }
        if (blockCS == null && circleCS == null) return;   // coba lagi frame berikutnya
        h.conn.setGlass(blockCS, circleCS, circleState);
        h.strip.setGlass(circleCS, circleState);
        h.skinned = true;
        XposedBridge.log("IOSQS skin: blok=" + blockName + " | tombol=" + tileViewName + " -> " + circleName);
    }

    private static void disableAnimator(ViewGroup rv) {
        try {
            for (Method m : rv.getClass().getMethods()) {
                if (m.getName().equals("setItemAnimator") && m.getParameterTypes().length == 1) {
                    m.invoke(rv, new Object[]{null});
                    XposedBridge.log("IOSQS: item animator dimatikan");
                    return;
                }
            }
        } catch (Throwable t) {
            XposedBridge.log("IOSQS: gagal matikan animator: " + t);
        }
    }

    private static void resize(View v, int w, int hh) {
        ViewGroup.LayoutParams lp = v.getLayoutParams();
        if (lp.width != w || lp.height != hh) {
            lp.width = w;
            lp.height = hh;
            v.setLayoutParams(lp);
        }
    }
}
