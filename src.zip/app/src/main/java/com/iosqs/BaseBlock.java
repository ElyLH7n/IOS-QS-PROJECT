package com.iosqs;

import android.content.Context;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

public abstract class BaseBlock extends ViewGroup {
    public Runnable preDraw;
    private final ViewTreeObserver.OnPreDrawListener listener = new ViewTreeObserver.OnPreDrawListener() {
        @Override public boolean onPreDraw() {
            if (preDraw != null) preDraw.run();
            return true;
        }
    };

    public BaseBlock(Context c) { super(c); }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), MeasureSpec.getSize(h));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        getViewTreeObserver().addOnPreDrawListener(listener);
        onShown();
    }

    @Override
    protected void onDetachedFromWindow() {
        getViewTreeObserver().removeOnPreDrawListener(listener);
        onHidden();
        super.onDetachedFromWindow();
    }

    protected void onShown() {}
    protected void onHidden() {}

    protected void place(android.view.View v, int x, int y, int w, int h) {
        v.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
                  MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
        v.layout(x, y, x + w, y + h);
    }
}
