package com.iosqs;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;

/** View transparan di posisi blok; meneruskan sentuhan ke blok yang tinggal di dalam sel asli. */
public class TouchProxy extends View {
    public View target;
    public Runnable preDraw;
    private final ViewTreeObserver.OnPreDrawListener listener = new ViewTreeObserver.OnPreDrawListener() {
        @Override public boolean onPreDraw() {
            if (preDraw != null) preDraw.run();
            return true;
        }
    };

    public TouchProxy(Context c) {
        super(c);
        setWillNotDraw(true);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        return target != null && target.dispatchTouchEvent(e);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        getViewTreeObserver().addOnPreDrawListener(listener);
    }

    @Override
    protected void onDetachedFromWindow() {
        getViewTreeObserver().removeOnPreDrawListener(listener);
        super.onDetachedFromWindow();
    }
}
