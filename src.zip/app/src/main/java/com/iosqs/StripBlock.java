package com.iosqs;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

public class StripBlock extends BaseBlock {
    static final String P_LOCK = "M18,8h-1V6c0,-2.76 -2.24,-5 -5,-5S7,3.24 7,6v2H6c-1.1,0 -2,0.9 -2,2v10c0,1.1 0.9,2 2,2h12c1.1,0 2,-0.9 2,-2V10c0,-1.1 -0.9,-2 -2,-2zM12,17c-1.1,0 -2,-0.9 -2,-2s0.9,-2 2,-2 2,0.9 2,2 -0.9,2 -2,2zM15.1,8H8.9V6c0,-1.71 1.39,-3.1 3.1,-3.1 1.71,0 3.1,1.39 3.1,3.1v2z";
    static final String P_CAST = "M21,3H3c-1.1,0 -2,0.9 -2,2v3h2V5h18v14h-7v2h7c1.1,0 2,-0.9 2,-2V5c0,-1.1 -0.9,-2 -2,-2zM1,18v3h3c0,-1.66 -1.34,-3 -3,-3zM1,14v2c2.76,0 5,2.24 5,5h2c0,-3.87 -3.13,-7 -7,-7zM1,10v2c4.97,0 9,4.03 9,9h2c0,-6.08 -4.93,-11 -11,-11z";

    private final IconBtn lock, cast;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable poll = new Runnable() {
        @Override public void run() { lock.setActive(Sys.rotationLocked(getContext())); handler.postDelayed(this, 1000); }
    };

    public StripBlock(final Context c) {
        super(c);
        lock = new IconBtn(c, P_LOCK, 0xFFFF3B30);   // aktif: putih + ikon merah
        cast = new IconBtn(c, P_CAST, 0xFF1F6BFF);
        addView(lock);
        addView(cast);
        lock.setOnClickListener(new OnClickListener() {
            public void onClick(View v) { Sys.toggleRotationLock(c); lock.setActive(Sys.rotationLocked(c)); }
        });
        cast.setOnClickListener(new OnClickListener() {
            public void onClick(View v) { Sys.open(c, "android.settings.CAST_SETTINGS"); }
        });
    }

    public void setGlass(android.view.View circleView) {
        lock.setGlass(circleView);
        cast.setGlass(circleView);
    }

    @Override protected void onShown() { handler.post(poll); }
    @Override protected void onHidden() { handler.removeCallbacks(poll); }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int W = r - l, H = b - t;
        int d = Math.min(H, (W - 8) / 2);
        place(lock, 0, (H - d) / 2, d, d);
        place(cast, W - d, (H - d) / 2, d, d);
    }
}
