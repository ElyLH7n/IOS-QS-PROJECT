package com.iosqs;

import android.view.ViewGroup;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class Main implements IXposedHookLoadPackage {
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) return;
        try {
            Class<?> rv = XposedHelpers.findClass("androidx.recyclerview.widget.RecyclerView", lp.classLoader);
            XposedHelpers.findAndHookMethod(rv, "onLayout",
                    boolean.class, int.class, int.class, int.class, int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            try {
                                Layouter.apply((ViewGroup) p.thisObject);
                            } catch (Throwable t) {
                                XposedBridge.log("IOSQS apply error: " + t);
                            }
                        }
                    });
            XposedBridge.log("IOSQS: hook RecyclerView.onLayout terpasang");
        } catch (Throwable t) {
            XposedBridge.log("IOSQS: gagal pasang hook: " + t);
        }
    }
}
