package com.iosqs;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import android.view.View;

/** Tombol bulat gaya ColorOS: nonaktif = latar kaca bawaan tile, aktif = putih + ikon berwarna. */
public class IconBtn extends View {
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ic = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path;
    private boolean active;
    private Drawable glass;
    public int activeBg = 0xFFFFFFFF;
    public int activeIcon;
    public int inactiveBg = 0x40808080;
    public int inactiveIcon = 0xFFFFFFFF;

    public IconBtn(Context c, String pathData, int activeIconColor) {
        super(c);
        path = Sys.parsePath(pathData);
        activeIcon = activeIconColor;
        ic.setStyle(Paint.Style.FILL);
    }

    public void setGlass(Drawable.ConstantState cs, int[] state) {
        if (cs == null) return;
        try {
            glass = cs.newDrawable(getResources()).mutate();
            if (state != null) glass.setState(state);
            invalidate();
        } catch (Throwable t) { glass = null; }
    }

    public void setActive(boolean a) {
        if (a != active) { active = a; invalidate(); }
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight(), r = Math.min(w, h) / 2f;
        if (active) {
            bg.setColor(activeBg);
            cv.drawCircle(w / 2f, h / 2f, r, bg);
        } else if (glass != null) {
            glass.setBounds(0, 0, getWidth(), getHeight());
            glass.draw(cv);
        } else {
            bg.setColor(inactiveBg);
            cv.drawCircle(w / 2f, h / 2f, r, bg);
        }
        if (path != null) {
            float s = r / 24f;
            ic.setColor(active ? activeIcon : inactiveIcon);
            cv.save();
            cv.translate(w / 2f - 12f * s, h / 2f - 12f * s);
            cv.scale(s, s);
            cv.drawPath(path, ic);
            cv.restore();
        }
    }
}
