package com.iosqs;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.View;

/** Tombol bulat gaya ColorOS: nonaktif = latar kaca tile asli, aktif = putih + ikon berwarna. */
public class IconBtn extends View {
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ic = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path;
    private boolean active;
    private View glassView;
    public int activeBg = 0xFFFFFFFF;
    public int activeIcon;
    public int inactiveIcon = 0xFFFFFFFF;

    public IconBtn(Context c, String pathData, int activeIconColor) {
        super(c);
        path = Sys.parsePath(pathData);
        activeIcon = activeIconColor;
        ic.setStyle(Paint.Style.FILL);
    }

    /** View latar milik tile asli yang akan digambar ulang di sini (tanpa ikon/teks). */
    public void setGlass(View v) {
        glassView = v;
        invalidate();
    }

    public void setActive(boolean a) {
        if (a != active) { active = a; invalidate(); }
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight(), r = Math.min(w, h) / 2f;
        if (active) {
            bg.setColor(activeBg);
            cv.drawCircle(w / 2f, h / 2f, r, bg);
        } else if (!drawNative(cv)) {
            // Tiruan kaca (dipakai kalau tile asli tidak bisa dipinjam)
            bg.setShader(new LinearGradient(0, 0, 0, h, 0x30FFFFFF, 0x14FFFFFF, Shader.TileMode.CLAMP));
            cv.drawCircle(w / 2f, h / 2f, r, bg);
            bg.setShader(null);
            float sw = Math.max(2f, w * 0.013f);
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(sw);
            rim.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{0xB0FFFFFF, 0x12FFFFFF, 0x12FFFFFF, 0x78FFFFFF},
                    new float[]{0f, 0.42f, 0.58f, 1f}, Shader.TileMode.CLAMP));
            cv.drawCircle(w / 2f, h / 2f, r - sw / 2f, rim);
        }
        if (path != null) {
            float s = r / 24f;
            ic.setColor(active ? activeIcon : inactiveIcon);
            cv.save();
            cv.translate(w / 2f - 12f * s, h / 2f - 12f * s);
            cv.scale(s, s);
            cv.drawPath(path, ic);
            cv.restore();
        }
    }

    private boolean drawNative(Canvas cv) {
        View g = glassView;
        if (g == null || g.getWidth() <= 0 || g.getHeight() <= 0 || !g.isAttachedToWindow()) return false;
        try {
            cv.save();
            cv.scale((float) getWidth() / g.getWidth(), (float) getHeight() / g.getHeight());
            g.draw(cv);
            cv.restore();
            return true;
        } catch (Throwable t) {
            glassView = null;
            return false;
        }
    }
}
